<template>
  <div>
      <h2>线性进度条---------百分比外显</h2>
      <Y-progress :percentage="0"  :show-text="false"/>
      <!-- 属性是字符串类型的不需要绑定直接添加 -->
      <Y-progress :percentage="50" color="orange"/>
      <Y-progress :percentage="80" status="success"/>
      <Y-progress :percentage="80" status="exception"/>

      <br>
            <h2>线性进度条---------百分比内显</h2>
      <Y-progress :strokewidth="18" :percentage="0"  text-inside="true"/>
      <Y-progress :strokewidth="18" :percentage="45"  text-inside="true"/>
      <Y-progress :strokewidth="18" :percentage="60" status="success" :text-inside="true"/>
      <Y-progress :strokewidth="18" :percentage="80" status="exception" :text-inside="true"/>

  </div>  
</template>
<script>
import YProgress from './Progress';
export default {
    components:{
      YProgress  
    },
    data(){
        
    }
}
</script>