<template>
<div class="progress" :class="[
status ? 'is-${status}' : '']">
<div class="progress-bar">
    <div class="progress-bar_outer" :style="{height:strokewidth+ 'px'}">
        <div class="progress-bar_inner" :style="barstyle">
            <div class="progress-bar_innerText" v-if="textInside&&showText">{{percentage}}%</div>
        </div>
    </div>
</div>
<div class="progress__text"
v-if="!textInside&&showText"
 :style="{fontSize: prgressTextSize+'px',color:stroke}">
 <template v-if="!status"> {{percentage}}%</template>
   <i v-else class="icon" :class="iconClass"></i>
</div>
</div>    
</template>
<script>
export default {
    props:{
        strokewidth:{
            type:Number,
            default:6
        },
        percentage:{
            type:Number,
            required:true,
            default:0,
            valadator(value){
                return value >=0 && value <=100
            }
        },
        status:{
          type:String  
        },
        type:{
            type:String,
            default:'line',
            valadator(val){
                return  ['circle','line'].includes(val);
            }
        },
        textInside:{
            type:Boolean,
            default:false,
        },
        showText:{
            type:Boolean,
            default:true
        },
        color:{
            type:String
        }
    },
    computed:{
        prgressTextSize(){
            return 12+this.strokewidth*0.4;
        },
        stroke(){
            let color;
            if(this.color){
                return this.color;
            }
            switch(this.status){
               case 'success':color='#13ce66';
               break;
               case 'exception':color='#ff4949';
               break;
               default:
                   color='#20a0ff'
            }
            return color;
        },
        barstyle(){
            return {width:this.percentage+'%',backgroundColor:this.stroke};
        },
        iconClass(){
            if(this.type==='line'){
                return this.status==='success'
                ?'icon-circle-check'
                :'icon-circle-close'
            }else{
                return this.status==='success'
                ?'icon-check'
                :'icon-close'
            }
        },
    }
}
</script>
<style>
/* @font-face {
    font-family:'icon';
    src: url('./icon/iconfont.eot');
    src: url('./icon/iconfont.eot?#iefix') format('embedded-opentype'),
    url('./icon/iconfont.woff2') format('woff2'),
    url('./icon/iconfont.woff') format('woff'),
    url('./icon/iconfont.ttf') format('truetype'),
    url('./icon/iconfont.svg#iconfont') format('svg');
} */
@font-face {
  font-family: 'iconfont';  /* project id 1408962 */
  src: url('//at.alicdn.com/t/font_1408962_2k5w5m2la7h.eot');
  src: url('//at.alicdn.com/t/font_1408962_2k5w5m2la7h.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_1408962_2k5w5m2la7h.woff2') format('woff2'),
  url('//at.alicdn.com/t/font_1408962_2k5w5m2la7h.woff') format('woff'),
  url('//at.alicdn.com/t/font_1408962_2k5w5m2la7h.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_1408962_2k5w5m2la7h.svg#iconfont') format('svg');
}
.icon{
    font-family: 'iconfont' !important;
    font-size: 16px;
    font-style: normal;
}
.icon-circle-check::before{
    content:'\e677';
}
.icon-circle-close::before{
    content:'\e605';
}
.icon-check::before{
    content:'\e742';
}
.icon-close::before{
    content:'\e627'
}
.progress-bar{
    width:calc(100% - 50px);
    display: inline-block;
}
.progress-bar_outer{
    border-radius: 100px;
    background-color: #ebeef5;
}
.progress-bar_inner{
    height: 100%;
    background-color: red;
    border-radius: 100px;
    transition: width .6s ease;
    text-align: right;
    line-height: 1px;
}
.progress.is-success .progress__text{
    color:#67c23a;
}
.progress.is.exception .progress__text{
    color:#f56c6c;
}
.progress__text{
    display:inline-block;
    margin-left:10px;
    color:#606266;
}
.progress-bar_innerText{
    color:#fff;
    display: inline-block;
   font-size:12px;
   margin-top: 8px;
   margin-right: 8px;
   vertical-align: middle;
}
</style>
