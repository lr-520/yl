var express = require('express');
var router = express.Router();
var mongoose=require('mongoose');
mongoose.connect("mongodb://172.30.60.18/yl",function(err){
	if(err){
		throw err;
	}else{
		console.log("数据库连接成功");
	}
});
var listSchema=new mongoose.Schema({
	title:String,
	author:String,
	from:String,
	content:String,
	time:String,
	hits:String
});
var listModel=mongoose.model('list',listSchema,'list');


/* GET home page. */
router.get('/',function(req, res, next) {
//res.render('index', { title: 'Express' });
listModel.find().exec(function(err,data){
		res.render('newslist.ejs',{list:data});
	});
});

router.get('/list.html',function(req,res){
	listModel.find().exec(function(err,data){
		res.render('newslist.ejs',{list:data});
	});
});

router.post('/save_add.html',function(req,res){
	var title=req.body.title;
	var author=req.body.author;
	var from=req.body.from;
	var content=req.body.content;
//	console.log(title,author,from,content);

	var list=new listModel();
	list.title=title;
	list.author=author;
	list.from=from;
	list.content=content;
	list.time=new Date().toLocaleString();
	list.hits=1;
	list.save(function(){
		res.send('<script>alert("发布成功");location.href="/list.html";</script>');
		
	});
});

router.get('/del.html',function(req,res){
	var id=req.query.id;
	listModel.findById(id).exec(function(err,data){
		data.remove(function(){
			res.send('<script>alert("删除成功");location.href="/list.html";</script>');
		});
		
	});
});
router.get('/edit.html',function(req,res){
	var id=req.query.id;
	listModel.findById(id).exec(function(err,data){
		res.render('newsedit.ejs',{news:data});
	});
});
router.post('/save_edit.html',function(req,res){
	var title=req.body.title;
	var author=req.body.author;
	var from =req.body.from;
	var content=req.body.content;
	var id=req.body.id;
	listModel.findById(id).exec(function(err,data){
//		console.log(err);
		data.title=title;
		data.author=author;
		data.from=from;
		data.content=content;
		data.save(function(err){
			res.send('<script>alert("恭喜你修改成功");location.href="/list.html";</script>');
		});
	});
});
module.exports = router;
